# SliderImage
Android SliderImage

allprojects {
		repositories {
			...
			maven { url 'https://jitpack.io' }
		}
	}
  
  dependencies {
	        compile 'com.github.thinkgood2830:SliderImage:0893a5b32f'
	}
